/**********************************************************************************************************************
    Program Name    : Sample program for Renesas Flash Driver (RFD RL78 Type01) (Data Flash)
    
    File Name       : sample_data_initsct.c
    Program Version : V1.20.00
    Device(s)       : RL78/G23 microcontroller
    Description     : Sample program for copying the sections for Data Flash Control. 
**********************************************************************************************************************/

/**********************************************************************************************************************
    DISCLAIMER
    This software is supplied by Renesas Electronics Corporation and is only intended for use with
    Renesas products. No other uses are authorized. This software is owned by Renesas Electronics
    Corporation and is protected under all applicable laws, including copyright laws.
    THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE,
    WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
    TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR
    ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR
    CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
    BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
    Renesas reserves the right, without notice, to make changes to this software and to discontinue the
    availability of this software. By using this software, you agree to the additional terms and conditions
    found by accessing the following link:
    http://www.renesas.com/disclaimer
    
    Copyright (C) 2024 Renesas Electronics Corporation. All rights reserved.
**********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "sample_data_initsct.h"

/**********************************************************************************************************************
 * Function name : Sample_Data_INITSCT
 *********************************************************************************************************************/
/**
 *  Sample function for copying the sections for data flash control.
 *  
 *  @param[in]     -
 *  @return            -
 */
/*********************************************************************************************************************/
extern __far unsigned char _RFD_DATAromstart;
extern __far unsigned char _RFD_DATAromend;
extern __near unsigned char _RFD_DATAstart;

unsigned char __far *d_rom_sectop = &_RFD_DATAromstart;     /* Copy source section top address */
unsigned char __far *d_rom_secend = &_RFD_DATAromend;       /* Copy source section end address+1 */
unsigned char __near *d_ram_sectop = &_RFD_DATAstart;       /* Copy destination section top address */

R_RFD_FAR_FUNC void Sample_Data_INITSCT(void)
{
        unsigned char __far *rom_p;
        unsigned char __near *ram_p;

        rom_p = d_rom_sectop;
        ram_p = d_ram_sectop;
        for ( ; rom_p != d_rom_secend; rom_p++, ram_p++) {
                *ram_p = *rom_p;
        }
}
